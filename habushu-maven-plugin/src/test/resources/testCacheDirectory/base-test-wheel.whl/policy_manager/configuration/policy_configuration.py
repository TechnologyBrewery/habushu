###
# #%L
# Policy-Based Configuration::Policy Manager (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from krausening.properties import PropertyManager


class PolicyConfiguration:
    """
    PolicyConfiguration is used to configure the policy location and defaults.
    """

    def __init__(self) -> None:
        self.properties = PropertyManager.get_instance().get_properties(
            "policy-configuration.properties"
        )

    def policiesLocation(self) -> str:
        """
        Configures the location and file name of the file that contains the
        policies.
        """
        return self.properties["policies-location"]
