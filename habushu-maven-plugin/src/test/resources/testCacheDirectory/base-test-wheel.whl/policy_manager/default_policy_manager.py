###
# #%L
# Policy-Based Configuration::Policy Manager (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from .abstract_policy_manager import AbstractPolicyManager


class DefaultPolicyManager(AbstractPolicyManager):
    """
    DefaultPolicyManager represents the singleton policy manager that can
    reuse the methods laid out by the AbstractPolicyManager.
    """

    __instance = None

    def __init__(self):
        if DefaultPolicyManager.__instance is not None:
            raise Exception("Class is a singleton")
        else:
            super().__init__()
            DefaultPolicyManager.__instance = self

    @staticmethod
    def getInstance():
        if DefaultPolicyManager.__instance is None:
            DefaultPolicyManager()
        return DefaultPolicyManager.__instance
