###
# #%L
# AIOps Foundation::AIOps Core (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from krausening.logging import LogManager
from aiops_core_config import MessagingConfig
from .metadata_api import MetadataAPI
from .metadata_model import MetadataModel
from typing import Dict, List
from kafka import KafkaProducer
import json
import jsonpickle


class HiveMetadataAPIService(MetadataAPI):
    """
    Class to handle basic logging of metadata.
    """

    logger = LogManager.get_instance().get_logger("HiveMetadataAPIService")

    def __init__(self):
        self.config = MessagingConfig()
        self.producer = KafkaProducer(
            bootstrap_servers=[self.config.server()], api_version=(2, 0, 2)
        )

    def create_metadata(self, metadata: MetadataModel) -> None:
        if metadata:
            out = jsonpickle.encode(metadata.dict()).encode()
            self.producer.send(self.config.metadata_topic(), value=out)
        else:
            HiveMetadataAPIService.logger.warn("Attempting to create null metadata.")

    def get_metadata(self, search_params: Dict[str, any]) -> List[MetadataModel]:
        return []
