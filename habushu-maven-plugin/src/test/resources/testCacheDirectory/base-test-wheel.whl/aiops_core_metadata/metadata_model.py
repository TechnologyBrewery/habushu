###
# #%L
# AIOps Foundation::AIOps Core (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from pydantic import BaseModel
from datetime import datetime
from typing import Dict
from uuid import uuid4


class MetadataModel(BaseModel):
    """
    Class that represents a common metadata model.

    resource
        the identifier of the data
    subject
        the thing acting on the data
    action
        the action being taken
    timestamp
        the time representing when the action occurred
    additionalValues
        additional values to be included in key-value pairs. Using camel-case notation to align with java implementations
        that will write to the same table
    """

    resource: str = uuid4().hex
    subject: str = ""
    action: str = ""
    timestamp: datetime = datetime.now().timestamp()
    additionalValues: Dict[str, str] = dict()
