###
# #%L
# AIOps Foundation::AIOps Core (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from abc import ABC, abstractmethod
from typing import Dict, List
from .metadata_model import MetadataModel


class MetadataAPI(ABC):
    """
    API for a metadata service.
    """

    @abstractmethod
    def create_metadata(self, metadata: MetadataModel) -> None:
        """
        Method to create metadata.
        """
        pass

    @abstractmethod
    def get_metadata(self, search_params: Dict[str, any]) -> List[MetadataModel]:
        """
        Method to get metadata from search criteria.
        """
        pass
