###
# #%L
# AIOps Foundation::AIOps Core (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from .inference_request import InferenceRequest


class InferenceRequestBatch:
    """Contains details necessary for inference to be invoked on a batch"""

    __row_id_key: str
    __data: list[InferenceRequest]

    def __init__(self, row_id_key: str, data: list[InferenceRequest]):
        self.row_id_key = row_id_key
        self.data = data

    @property
    def row_id_key(self) -> str:
        return self.__row_id_key

    @row_id_key.setter
    def row_id_key(self, new_value):
        self.__row_id_key = new_value

    @property
    def data(self) -> list[InferenceRequest]:
        return self.__data

    @data.setter
    def data(self, new_value):
        self.__data = new_value
