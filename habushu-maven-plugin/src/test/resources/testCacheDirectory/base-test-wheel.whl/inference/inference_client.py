###
# #%L
# AIOps Foundation::AIOps Core (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
import abc

from .inference_config import InferenceConfig
from .inference_request import InferenceRequest
from .inference_request_batch import InferenceRequestBatch
from .inference_result import InferenceResult
from .inference_result_batch import InferenceResultBatch


class InferenceClient(metaclass=abc.ABCMeta):
    """Interface for inference client."""

    _config: InferenceConfig

    def __init__(self):
        self._config = InferenceConfig()

    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, "infer")
            and callable(subclass.infer)
            and hasattr(subclass, "infer_batch")
            and callable(subclass.infer_batch)
        )

    @abc.abstractmethod
    async def infer(self, inference_request: InferenceRequest) -> InferenceResult:
        """Invoke inference"""
        raise NotImplementedError

    @abc.abstractmethod
    async def infer_batch(
        self, inference_request_batch: InferenceRequestBatch
    ) -> list[InferenceResultBatch]:
        """Invoke inference on batch"""
        raise NotImplementedError
