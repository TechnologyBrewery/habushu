###
# #%L
# AIOps Foundation::AIOps Core (Python)
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from krausening.properties import PropertyManager


class MessagingConfig:
    """
    Configurations for messaging connections
    """

    def __init__(self) -> None:
        self.properties = PropertyManager.get_instance().get_properties(
            "messaging.properties"
        )

    def server(self) -> str:
        """
        Server address
        """
        return self.properties.getProperty("server", "kafka-cluster:9093")

    def metadata_topic(self) -> str:
        """
        Topic for metadata
        """
        return self.properties.getProperty("metadata_topic", "metadata-ingest")
