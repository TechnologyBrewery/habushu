# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['krausening_python',
 'krausening_python.logging',
 'krausening_python.properties']

package_data = \
{'': ['*']}

install_requires = \
['javaproperties>=0.8.1,<0.9.0', 'pycryptodome>=3.14.1,<4.0.0']

setup_kwargs = {
    'name': 'krausening-python',
    'version': '10.0.0',
    'description': 'Python implementation of Krausening',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.9.9',
}


setup(**setup_kwargs)
